__iconsData: {
    
        'icon-arrow-right': {
            width: '154.367px',
            height: '283.461px'
        },
    
        'icon-doc': {
            width: '219.926px',
            height: '283.461px'
        },
    
        'icon-i': {
            width: '283.46px',
            height: '262.641px'
        },
    
        'icon-locate': {
            width: '283.46px',
            height: '283.461px'
        },
    
        'icon-miting': {
            width: '64px',
            height: '64px'
        },
    
        'icon-pdf': {
            width: '398.121px',
            height: '512px'
        },
    
        'icon-ppt': {
            width: '219.926px',
            height: '283.461px'
        },
    
        'icon-txt': {
            width: '219.926px',
            height: '283.461px'
        },
    
}